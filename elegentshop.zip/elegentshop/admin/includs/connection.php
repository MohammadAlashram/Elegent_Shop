<?php
 $conn = mysqli_connect("localhost","root","","elegentshop");
    if(!$conn){
        die("cannot connect to server");
    }
?>